package com.example.example;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("atacado")
public class ItemController {

	@Autowired
	private AtacadoServiceImagem AtacadoServiceImagem;

	@Autowired
	ItemRepository repo;

	@GetMapping("/listar")
	public List<ItemModel> listar() {
		return AtacadoServiceImagem.listarTodos();
	}

	@PostMapping("/criar")
	public ResponseEntity<ItemModel> criar(@RequestBody ItemModel ItemImagem) {
		System.out.println("URL da imagem recebida: " + ItemImagem.getImagem());
		return new ResponseEntity<>(AtacadoServiceImagem.salvar(ItemImagem), HttpStatus.CREATED);
	}

	@GetMapping("/listar/{id}")
	public ResponseEntity<ItemModel> buscarPorId(@PathVariable Long id) {
		ItemModel ItemImagem = AtacadoServiceImagem.buscarPorId(id);
		return ItemImagem != null ? ResponseEntity.ok(ItemImagem) : ResponseEntity.notFound().build();
	}

	@PutMapping("/atualizar/{id}")
	public ResponseEntity<?> atualizarItem(@PathVariable Long id, @RequestBody ItemDTO dto) {
		ItemModel item = repo.findById(id)
				.orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Item não encontrado"));

		// Atualizar as propriedades com os dados do DTO
		item.updatedDTO(dto);

		// Salvar atualizado no banco de dados
		repo.save(item);

		return ResponseEntity.ok(item); // Retornar atualizado
	}

	@DeleteMapping("/deletar/{id}")
	public ResponseEntity<Void> deletar(@PathVariable Long id) {
		AtacadoServiceImagem.deletar(id);
		return ResponseEntity.noContent().build();
	}
}
