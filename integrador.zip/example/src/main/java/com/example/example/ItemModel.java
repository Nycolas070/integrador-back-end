package com.example.example;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "items2")
public class ItemModel {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	private String imagem;
	private String nome;
	private String preco;
	
	public ItemModel() {

	}

	public ItemModel(ItemDTO itemImagem) {
		this.imagem = imagem;
		this.nome = nome;
		this.preco = preco;
	}

	public ItemModel(Long id, String imagem, String nome, String preco) {

		this.id = id;
		this.imagem = imagem;
		this.nome = nome;
		this.preco = preco;

	}

	public void updatedDTO(ItemDTO dto) {

		this.imagem = dto.imagem();
		this.nome = dto.nome();
		this.preco = dto.preco();

	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getImagem() {
		return imagem;
	}

	public void setImagemUrl(String imagem) {
		this.imagem = imagem;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getPreco() {
		return preco;
	}

	public void setPreco(String preco) {
		this.preco = preco;
	}

}