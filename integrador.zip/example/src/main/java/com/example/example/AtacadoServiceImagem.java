package com.example.example;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AtacadoServiceImagem {

	@Autowired
	private ItemRepository repo;

	public List<ItemModel> listarTodos() {
		return repo.findAll();
	}

	public ItemModel salvar(ItemModel item) {
		return repo.save(item);
	}

	public ItemModel buscarPorId(Long id) {
		return repo.findById(id).orElse(null);
	}

	public void deletar(Long id) {
		repo.deleteById(id);
	}

}
