package com.example.example;

public record ItemDTO(String nome, String preco,String imagem) {

}